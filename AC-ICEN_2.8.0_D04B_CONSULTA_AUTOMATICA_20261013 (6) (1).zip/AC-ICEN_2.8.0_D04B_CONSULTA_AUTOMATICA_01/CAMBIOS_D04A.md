# D04-A — Biblioteca Jurídica conectada

- Se conservó la aplicación de 55 pantallas de D03. La versión canónica 2.7.0 no se modifica.
- Nuevo servicio HTTP exclusivamente local (127.0.0.1:8765), base SQLite y botones de consulta normativa en Análisis de la contraparte.
- Consulta de plazos de pago: Ley 19.983 artículos 2, 2 bis y 2 ter; Ley 21.131 como modificatoria, con enlaces oficiales a BCN.
- La interfaz muestra fundamentos resumidos y enlace de fuente solo cuando se despliegan, sin informes automáticos por artículo.
- **Alcance real:** referencias normativas candidatas, no texto íntegro ni vigencia histórica confirmada por artículo. No se realiza interpretación jurídica autónoma ni se altera la calculadora.
- Inicio: doble clic en `INICIAR_ICEN_D04A.bat` con Python 3 instalado. Navegador se abre en localhost.
