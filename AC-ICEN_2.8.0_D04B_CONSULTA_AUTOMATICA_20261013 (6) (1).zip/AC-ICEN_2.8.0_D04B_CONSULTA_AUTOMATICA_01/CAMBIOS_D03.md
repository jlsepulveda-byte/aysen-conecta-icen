# AC-ICEN 2.8.0 — D03 Consolidación funcional

Se partió exclusivamente de la entrega integrada de Claude. La base canónica no fue modificada.

## Corrección implementada
- Reconocimiento ampliado de FORMACION_ORDEN: «Orden de Servicio», «Orden de compra» y la forma abreviada «la Orden» cuando coexiste una expresión de activación/aceptación.
- Corregido el código fuente y reconstruido el HTML integrado con el constructor reproducible.
- Sin modificación de los bloqueos de exportación jurídica a la calculadora.

## Resultados verificados
- 55 pantallas únicas presentes.
- Huella SHA-256 de la canónica igual a la entrega de Claude.
- Materias detectadas en contrato maestro: FORMACION_ORDEN, EXCEPCIONES, JERARQUIA, PAGOS, GARANTIAS, RESPONSABILIDAD, CREDITOS_SERVICIO (7/7).
- Cláusulas candidatas: 65.
- Pruebas unitarias M7 y generalización ejecutadas con Node, exitosas.

## Advertencia
Las pruebas en navegador completas y la lectura visual de PDF/DOCX no se reejecutaron en esta entrega. No demuestra exactitud jurídica autónoma.

## Windows
Descomprimir la carpeta y ejecutar `ABRIR_AYSEN_CONECTA_2.8.0.bat`.
