# CHANGELOG · AC-ICEN-MVP_2.8.0_20261013_PROPUESTA
Base: AC-ICEN-MVP 2.7.0 CANONICA (intacta; copia y huella SHA-256 en `base_canonica/` y `base_sha256.txt`).
Estado: PROPUESTA. Solo pasa a CANONICA tras revisión e integración. Nota técnica dirigida a Carlos.

## Clasificación de aportes (Instrucción AC-ICEN-INST-1.0, §3)
| Aporte | Decisión | Detalle |
|---|---|---|
| Módulos M4, M5 (relaciones), M6, M7 del paquete «Analizador funcional 01» | INCORPORAR | Integrados dentro del HTML mediante `fuentes/motor_m7_bundle.js`. Se conservan los originales en `fuentes/originales_01/`. |
| Filtro de encabezados de M4 (texto fijo del caso maestro) | INCORPORAR CON CORRECCIONES | La regla fija contradecía la instrucción de no programar para un texto específico. Se reemplazó por detección genérica: línea repetida, con números normalizados, en el borde de ≥60 % de las páginas (mín. 3) y que no parezca inicio de cláusula. |
| Lector de PDF, DOCX y TXT | INCORPORAR (nuevo) | El paquete 01 solo leía TXT. Se construyó `lector_documental.js`: PDF con PDF.js 5.6.205 local, DOCX con JSZip 3.10.1 local, TXT con UTF-8 y respaldo Windows-1252. Detecta el tipo por contenido, no solo por extensión. |
| Página de demostración `ABRIR_ANALIZADOR_ICEN.html` | DESCARTAR como app | Su función queda dentro de «Análisis de la contraparte». Se conserva solo como fuente histórica. |
| Exportación JSON del analizador | NO INCORPORADA | No fue necesaria para el encargo; queda como candidata. |
| Mejoras del motor de extracción de la propuesta v2.6 (reglas por contrato real, programa de pago por hitos) | NO INCORPORADAS | No se mezclaron para no alterar el motor de 2.7.0. Pendiente de evaluación. |

## Cambios en la aplicación
- Se mantienen las 55 pantallas y todas las funciones de 2.7.0. No se agregó ninguna pantalla.
- «Análisis de la contraparte»: acepta `.docx`; botón «Contrato maestro (caso 2027-211)»; nueva sección «Evaluador contractual M7».
- Evaluador M7: diferencias entre cláusulas, observaciones estructurales y materias señaladas. Cada fragmento muestra documento, página, sección y texto, con visor que resalta el original. Calidad de extracción en categorías cualitativas (sin porcentajes): «Ambigua» y «Requiere revisión».
- Revisión humana por hallazgo: Sin revisar / Revisada por una persona / Descartada.
- Registro por documento: nombre, tipo, huella SHA-256, tamaño, fecha de lectura. No se carga dos veces el mismo archivo.
- Páginas: PDF informa página real. TXT y DOCX sin saltos de página declaran «página no disponible».

## Bloqueo de transferencia a la Calculadora ICEN (Reglas Maestras §13–§15, §17)
- Ninguna conclusión del evaluador M7 se transfiere. M7 mantiene `financialExportAllowed=false` y `legalConclusion=null`.
- Los valores numéricos del análisis existente solo pasan con la casilla de confirmación humana.
- Además, quedan retenidos los campos vinculados a hallazgos sin revisar: plazos y estructura de pago (pago, anticipo, retención, liberación) y exposición a multa. Se liberan cuando una persona marca el hallazgo como revisado o descartado. La calculadora informa en «Origen de los datos» qué quedó retenido.

## Funciones de 2.7.0 modificadas en la capa nueva (aditivo)
`mvAdd` (redefinida: nuevo lector), `mvRun`, `mvClear`, `mvSend` (envueltas). El resto no cambia.

## Descartado y por qué
- Porcentajes de «confianza»: prohibidos por Reglas Maestras §12.
- Resolver prelaciones o contradicciones automáticamente: prohibido por §13.
