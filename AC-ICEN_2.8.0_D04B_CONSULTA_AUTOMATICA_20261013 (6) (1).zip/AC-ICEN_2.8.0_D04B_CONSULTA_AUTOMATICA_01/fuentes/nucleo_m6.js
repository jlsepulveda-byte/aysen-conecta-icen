'use strict';
/** M6: candidate rule model (not legal adjudication). Uses M5 extraction; no file mutation. */
const {analyze}=require('./relaciones');
const {segment}=require('./motor_m4');
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const reg={
  condition:/\b(si|siempre que|cuando|en caso de|durante el cual|sujeto a|solo si|una vez que)\b/i,
  except:/\b(salvo|excepto|a excepcion de|no operara|no se aplicara|sin perjuicio|excluid[oa]s?)\b/i,
  scope:/\b(especial|especific[oa]|critic[oa]|urgente|exclusivamente|unicamente)\b/i,
  override:/\b(derogacion especifica|prevalec|jerarquia|prelacion|modificar)\b/i,
  obligation:/\b(debera|debe|pagara|estara obligado|no excedera|se devenga|se aplicara|podra terminar|se entendera aceptada)\b/i
};
const has=(s,re)=>re.test(norm(s));
const evidence=(f)=>({documentId:f.source.documentId,page:f.source.page,section:f.source.section,quote:f.source.quote});
function analyzeM6(text,documentId='DOCUMENTO_SIN_ID'){
 const base=analyze(text,documentId);
 const rules=base.facts.map(f=>{
   const quote=f.source.quote, q=norm(quote);
   const tags={condition:has(q,reg.condition),exception:has(q,reg.except),specialScope:has(q,reg.scope),hierarchy:has(q,reg.override),obligation:has(q,reg.obligation)};
   const scopeTags=[...new Set([/\bcritic[oa]\b/.test(q)?'RECURSO_CRITICO':null,/\burgente\b/.test(q)?'ORDEN_URGENTE':null,/\borden(?:es)? de servicio\b/.test(q)?'ORDEN_SERVICIO':null,/\bprimeros?\s+(?:3|tres)\s+meses\b/.test(q)?'PRIMEROS_TRES_MESES':null].filter(Boolean))];
   return {id:`R-${f.id}`,topic:f.topic,actorCandidate:f.actor,kind:tags.hierarchy?'JERARQUIA_CANDIDATA':tags.exception?'EXCEPCION_CANDIDATA':tags.condition?'CONDICIONAL_CANDIDATA':tags.obligation?'OBLIGACION_CANDIDATA':'MENCION_CANDIDATA',tags,scopeTags,quantities:f.quantities,source:evidence(f),reviewRequired:true,approved:false};
 });
 // Restore topic context from the article heading for numbered clauses whose text omits the topic name.
 const segs=segment(text), headingTopics=new Map();
 const headingTerms=[['credito_servicio',/creditos? de servicio/i],['pago',/pagos?|facturaci[oó]n/i],['garantia',/garant[ií]as?/i],['responsabilidad',/responsabilidad/i],['orden',/orden(?:es)? de servicio/i]];
 let currentArticle=null;
 for(const seg of segs){
   const a=seg.section.match(/^ARTICULO (\d+)/), c=seg.section.match(/^CLAUSULA (\d+)\./);
   if(a){currentArticle=a[1];for(const [topic,re] of headingTerms)if(re.test(norm(seg.text)))headingTopics.set(currentArticle,topic);}
   if(c&& !rules.some(r=>r.source.page===seg.page&&r.source.section===seg.section&&r.source.quote===seg.text)){
      const topic=headingTopics.get(c[1]);
      if(topic && /\d+\s*%|\d+\s*d[ií]as?|\$\s*[\d.]+/.test(seg.text)){
       const q=norm(seg.text),tags={condition:has(q,reg.condition),exception:has(q,reg.except),specialScope:has(q,reg.scope),hierarchy:has(q,reg.override),obligation:has(q,reg.obligation)};
       rules.push({id:`R-CONTEXTO-${rules.length+1}`,topic,actorCandidate:null,kind:'CLAUSULA_CONTEXTO_CANDIDATA',tags,scopeTags:/\bcritic[oa]\b/.test(q)?['RECURSO_CRITICO']:[],quantities:[...seg.text.matchAll(/\d+(?:[.,]\d+)?\s*%|\d+\s+d[ií]as?|\$\s*[\d.]+/gi)].map(m=>({raw:m[0],start:m.index})),source:{documentId,page:seg.page,section:seg.section,quote:seg.text},reviewRequired:true,approved:false});
      }
   }
 }
 const relationAlerts=base.warnings.map(w=>({id:w.id,type:w.kind,topic:w.topic,source:w.sources,outcome:'PENDIENTE_REVISION',reason:w.reason}));
 // Cross-document hierarchy is a prerequisite check, not a definitive decision.
 const pageFacts=(...terms)=>rules.filter(r=>terms.every(t=>norm(r.source.quote).includes(norm(t))));
 const observations=[];
 const make=(code,label,arr,reason)=>{if(arr.length)observations.push({code,label,status:'REVISION_REQUERIDA',source:arr.slice(0,8).map(r=>r.source),reason});};
 // Generic trigger relationships (no contract identifiers or predetermined numeric answers).
 make('ACTIVACION_ORDEN','Regla de activación por orden',rules.filter(r=>r.topic==='orden'&&(r.tags.condition||/\baceptad|\bactiva|\bemitid|\breserv/.test(norm(r.source.quote)))),'Verificar aceptación efectiva, vigencia y recursos reservados antes de reconocer ingresos.');
 make('EXCEPCIONES','Excepciones o exclusiones expresas',rules.filter(r=>r.tags.exception),'Distinguir exclusión real, condición y alcance temporal; no resolver precedencia automáticamente.');
 make('PRELACION','Prelación o derogación documental',rules.filter(r=>r.tags.hierarchy),'Comparar requisito formal de derogación con contenido y nivel del documento citado.');
 // Detect issue when identical topic has different percentages but scope differs, including from same Article.
 for(const topic of ['credito_servicio','pago','responsabilidad','garantia']){
  const rr=rules.filter(r=>r.topic===topic);
  const values=new Set(rr.flatMap(r=>r.quantities.filter(q=>/%/.test(q.raw)).map(q=>q.raw.match(/\d+(?:[.,]\d+)?/)?.[0]?.replace(',','.')).filter(Boolean)));
  if(values.size>1){const scoped=rr.some(r=>r.tags.specialScope||r.tags.exception);make('PORCENTAJES_'+topic.toUpperCase(),`Diferentes porcentajes en ${topic}`,rr.filter(r=>r.quantities.some(q=>q.raw.includes('%'))),scoped?'Puede existir regla general y ámbito especial; comparar sujeto, base y evento.':'Comparar bases y supuestos antes de concluir conflicto.');}
 }
 // Multiple payment deadlines only if payment statements actually contain days.
 const payments=rules.filter(r=>r.topic==='pago'&&r.quantities.some(q=>/d[ií]as/i.test(q.raw)));
 const days=new Set(payments.flatMap(r=>r.quantities.filter(q=>/d[ií]as/i.test(q.raw)).map(q=>q.raw.match(/\d+/)?.[0])).filter(Boolean));
 if(days.size>1)make('PLAZOS_PAGO','Diferentes plazos asociados a pagos',payments,'Revisar si los plazos son vencimiento de factura, mora, validación, orden o terminación: no equipararlos sin contexto.');
 return {schema:'AC-ICEN-M6-NUCLEO-01',documentId,coverage:{candidateFacts:base.facts.length,ruleCandidates:rules.length,explicitReferences:base.edges.length,relationAlerts:relationAlerts.length,issueGroups:observations.length},rules,edges:base.edges,relationAlerts,observations,financialExport:{ready:false,approvedFacts:[],reason:'No está resuelta la validez jurídica ni las variables cuantitativas; exige revisión humana.'},limitations:['Clasificación basada en patrones y coocurrencia, no interpretación jurídica autónoma.','Una frase puede contener varias reglas y el programa puede unir sujetos, cantidades o ámbitos indebidamente.','No comprueba autenticidad documental, contratos completos ni documentos sustituidos.','Detectar distintos porcentajes o plazos no prueba contradicción ni prioridad.','M6 no calcula rentabilidad ni transmite variables a la calculadora.']};
}
module.exports={analyzeM6};
