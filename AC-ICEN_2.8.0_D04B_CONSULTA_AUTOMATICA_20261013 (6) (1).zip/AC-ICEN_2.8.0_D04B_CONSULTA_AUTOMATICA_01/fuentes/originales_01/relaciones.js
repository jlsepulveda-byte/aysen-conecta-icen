'use strict';
/** AC-ICEN M5: grafo de referencias contractuales, alertas provisionales.
 * No resuelve prevalencias jurídicas ni valida cifras económicamente.
 */
const {extract,segment}=require('./motor_m4');
const norm=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const REFS=[
 {kind:'CLAUSULA',re:/\b(?:art[ií]culo|art\.)\s*(\d{1,2})(?:\.(\d{1,2}))?\b/gi},
 {kind:'ANEXO',re:/\banexo\s+([a-z])\b/gi},
 {kind:'ORDEN',re:/\b(?:orden(?:es)?\s+de\s+servicio\s+)?(OS[-–]\d{2,})\b/gi}
];
function refsFrom(s){const out=[];for(const {kind,re} of REFS){for(const m of s.matchAll(re)){let dest=kind==='CLAUSULA'?(m[2]?`CLAUSULA ${m[1]}.${m[2]}`:`ARTICULO ${m[1]}`):kind==='ANEXO'?`ANEXO ${m[1].toUpperCase()}`:`ORDEN ${m[1].toUpperCase()}`; if(!out.includes(dest))out.push(dest);}}return out;}
function ownArticle(section){let m=section.match(/^(?:ARTICULO|CLAUSULA) (\d+)/);return m?`ARTICULO ${m[1]}`:null;}
function numbers(f){return f.quantities.flatMap(q=>{const raw=norm(q.raw);if(raw.includes('%'))return [{type:'PORCENTAJE',value:Number(raw.replace('%','').replace(',','.').trim()),raw:q.raw}];if(/dias?/.test(raw))return [{type:'DIAS',value:Number(raw.match(/\d+/)?.[0]),raw:q.raw}];if(raw.includes('$'))return [{type:'CLP',value:Number(raw.replace(/[^0-9,]/g,'').replace(/,/g,'.').split('.')[0].length===0?0:raw.replace(/\D/g,'')),raw:q.raw}];return []})}
function analyze(text,documentId='DOCUMENTO_SIN_ID'){
 const base=extract(text,documentId), all=segment(text);const sections=new Map();
 for(const n of all){if(!sections.has(n.section))sections.set(n.section,[]);sections.get(n.section).push(n)}
 const edges=[],warnings=[],facts=base.facts.map(f=>({...f,links:[],reviewRequired:true}));
 const index=new Map();for(const f of facts){if(!index.has(f.source.section))index.set(f.source.section,[]);index.get(f.source.section).push(f)}
 const byArt=new Map();for(const f of facts){const a=ownArticle(f.source.section);if(a){if(!byArt.has(a))byArt.set(a,[]);byArt.get(a).push(f)}}
 const unique=new Set();
 for(const f of facts){for(const ref of refsFrom(f.source.quote)){
   // A clause referring to itself is not a dependency.
   if(ref===f.source.section||ref===ownArticle(f.source.section))continue;
   const targets=index.get(ref)||byArt.get(ref)||[];
   const key=`${f.id}/${ref}`;if(unique.has(key))continue;unique.add(key);
   const edge={kind:'REFERENCIA_EXPRESA',from:f.id,to:ref,resolved:targets.length>0,targetFactIds:targets.map(t=>t.id),evidence:f.source,legalPriorityDetermined:false};edges.push(edge);f.links.push(edge);
 }}
 // Compare only like-for-like measures in the same topic across different clauses.
 // This is merely an alert for a reviewer; whether the scopes overlap is unknown.
 for(let i=0;i<facts.length;i++)for(let j=i+1;j<facts.length;j++){
   const a=facts[i],b=facts[j];if(a.topic!==b.topic||a.source.section===b.source.section)continue;
   const av=numbers(a),bv=numbers(b);const differing=[];
   for(const x of av)for(const y of bv)if(x.type===y.type&&Number.isFinite(x.value)&&Number.isFinite(y.value)&&x.value!==y.value)differing.push({type:x.type,left:x.raw,right:y.raw});
   if(!differing.length)continue;
   // Repeated mentions create many false positives. Keep only alerts for shared topic with differentiating numbers;
   // cap volume per topic while retaining the complete evidence for each emitted alert.
   const qualifier=/\b(salvo|excepto|especial|especific|unicamente|solo|urgente|derogacion|prevalec|cuando|siempre que)\b/.test(norm(a.source.quote+' '+b.source.quote));
   const k=[a.topic,a.source.section,b.source.section].join('/');if(warnings.some(w=>w.dedupKey===k))continue;
   if(warnings.filter(w=>w.topic===a.topic).length>=12)continue;
   warnings.push({id:`A${String(warnings.length+1).padStart(3,'0')}`,dedupKey:k,kind:qualifier?'POSIBLE_REGLA_ESPECIAL_O_AMBITO_DISTINTO':'DIFERENCIA_A_REVISAR',topic:a.topic,measureDifferences:differing.slice(0,4),factIds:[a.id,b.id],sources:[a.source,b.source],outcome:'NO_RESUELTO',humanReview:true,reason:'Los valores difieren, pero no se ha verificado igualdad de supuesto, vigencia ni jerarquía documental.'});
 }
 return {schema:'AC-ICEN-M5-RELACIONES-01',documentId,nodes:base.nodes,facts,edges,warnings,coverage:{candidateFacts:facts.length,explicitReferences:edges.length,potentialDifferences:warnings.length},financialExport:{ready:false,approvedFacts:[],reason:'No hay interpretación jurídica ni aprobación humana. No exportar importes ni plazos a cálculos.'},limitations:[...base.limitations,'El enlace explícito se detecta por expresiones regulares y puede asociar referencias al artículo equivocado.','Las diferencias numéricas generan alertas no resueltas; nunca se etiquetan como contradicciones confirmadas.','No identifica equivalencia semántica ni dependencia transversal sin referencia expresa.','La cobertura de las alertas se limita a 12 pares por materia para evitar inundación.']};
}
module.exports={analyze,refsFrom,numbers};
