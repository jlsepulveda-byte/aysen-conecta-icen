'use strict';
/** AC-ICEN 2.8.0 · Lector documental local (PDF, DOCX, TXT). No envía datos a ningún servidor. */
const LECTOR=(function(){
 const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
 const sha=async buf=>{try{return hex(await crypto.subtle.digest('SHA-256',buf))}catch(e){return null}};
 let pdfMod=null;
 async function cargarPdfJs(){
  if(pdfMod)return pdfMod;
  const src=document.getElementById('lib-pdfjs'),wk=document.getElementById('lib-pdfworker');
  if(!src||!wk)throw Error('El lector de PDF no está incluido en esta copia.');
  const url=u=>URL.createObjectURL(new Blob([u.textContent],{type:'text/javascript'}));
  pdfMod=await import(url(src));pdfMod.GlobalWorkerOptions.workerSrc=url(wk);return pdfMod;
 }
 function lineas(items){let o='',y=null;for(const it of items){if(typeof it.str!=='string')continue;const yy=it.transform?it.transform[5]:null;
  if(o!==''&&((y!==null&&yy!==null&&Math.abs(yy-y)>2)||it.hasEOL&&!it.str))o+='\n';else if(o!==''&&!/[\s]$/.test(o)&&it.str&&!/^\s/.test(it.str))o+=' ';
  o+=it.str;if(yy!==null)y=yy;if(it.hasEOL)o+='\n'}return o.replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim()}
 async function leerPdf(buf){const m=await cargarPdfJs();const d=await m.getDocument({data:new Uint8Array(buf.slice(0))}).promise;const pages=[];
  for(let i=1;i<=d.numPages;i++){const c=await(await d.getPage(i)).getTextContent();pages.push(lineas(c.items))}
  if(pages.join('').replace(/\s/g,'').length<40)throw Error('El PDF no contiene texto seleccionable (¿escaneado?). Este prototipo no hace OCR: pegue el texto del documento.');
  return pages}
 async function leerDocx(buf){if(typeof JSZip==='undefined')throw Error('El lector de DOCX no está incluido en esta copia.');
  const z=await JSZip.loadAsync(buf),f=z.file('word/document.xml');if(!f)throw Error('El archivo DOCX no contiene word/document.xml.');
  const xml=new DOMParser().parseFromString(await f.async('string'),'application/xml'),W='http://schemas.openxmlformats.org/wordprocessingml/2006/main',pages=[];let cur=[];
  const par=p=>{let t='',brk=false;const walk=n=>{for(const c of n.childNodes){if(c.nodeType!==1)continue;const ln=c.localName;
    if(ln==='t')t+=c.textContent;else if(ln==='tab')t+='\t';else if(ln==='br'||ln==='cr'){if(c.getAttributeNS(W,'type')==='page'){cur.push(t);t='';pages.push(cur.join('\n'));cur=[]}else t+='\n'}
    else if(ln==='lastRenderedPageBreak'){}else if(ln==='pPr'||ln==='rPr'||ln==='instrText')continue;else walk(c)}};walk(p);return t};
  const body=xml.getElementsByTagNameNS(W,'body')[0];
  const rec=n=>{for(const c of n.childNodes){if(c.nodeType!==1)continue;if(c.localName==='p')cur.push(par(c));else if(c.localName==='tbl'){for(const tr of c.getElementsByTagNameNS(W,'tr')){const cells=[...tr.getElementsByTagNameNS(W,'tc')].map(tc=>[...tc.getElementsByTagNameNS(W,'p')].map(par).join(' ').trim());cur.push(cells.join(' | '))}}else if(c.localName==='sdt'||c.localName==='customXml')rec(c);else if(c.localName==='sdtContent')rec(c)}};
  rec(body);pages.push(cur.join('\n'));
  if(pages.join('').replace(/\s/g,'').length<20)throw Error('El DOCX no contiene texto.');return pages}
 function decodificar(buf){let t=new TextDecoder('utf-8').decode(buf);if(t.includes('\ufffd'))t=new TextDecoder('windows-1252').decode(buf);return t.replace(/^\ufeff/,'')}
 function tipo(name,b){const h=new Uint8Array(b.slice(0,5));const s=String.fromCharCode(...h);
  if(s.startsWith('%PDF'))return'PDF';if(s.startsWith('PK')&&/\.docx$/i.test(name))return'DOCX';if(s.startsWith('PK'))return'ZIP';
  if(/\.pdf$/i.test(name))return'PDF_INVALIDO';if(/\.docx$/i.test(name))return'DOCX_INVALIDO';return'TXT'}
 async function leer(file){
  if(file.size>25e6)throw Error('Archivo demasiado grande (máximo 25 MB en este prototipo).');
  const buf=await file.arrayBuffer(),t=tipo(file.name,buf);let pages,paginado=true;
  if(t==='PDF')pages=await leerPdf(buf);
  else if(t==='DOCX'){pages=await leerDocx(buf);paginado=pages.length>1}
  else if(t==='TXT'){const x=decodificar(buf);if(!x.trim())throw Error('El archivo está vacío.');pages=x.split('\f');paginado=pages.length>1}
  else throw Error('Formato no admitido o archivo dañado ('+t+'). Use PDF con texto, DOCX o TXT.');
  return{name:file.name,type:t,pages,paginado,raw:pages.join('\f'),sha256:await sha(buf),size:file.size,leidoEn:new Date().toISOString()}}
 return{leer,tipo,decodificar,lineas};
})();
if(typeof module!=='undefined')module.exports=LECTOR;
