const ICEN=(function(){const modules={};const cache={};
modules["motor_m4"]=function(require,module,exports){
'use strict';
/** AC-ICEN M4 generalización 02. Extracción heurística, no interpretación jurídica. */
const norm=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const TERMS={pago:/\b(pago|pagara|factura|vencimiento|cobro)\b/,garantia:/\b(garantia|boleta de garantia|poliza)\b/,credito_servicio:/\b(credito[s]? de servicio|penalidad|descuento por desempeno|sla)\b/,responsabilidad:/\b(responsabilidad|indemnizacion|limite de responsabilidad)\b/,combustible:/\b(combustible|diesel|petroleo)\b/,orden:/\b(orden de servicio|ordenes de servicio)\b/};
function segment(text){
 if(typeof text!=='string'||!text.trim())throw Error('Se requiere texto contractual');
 let page=1,section='SIN_SECCION',out=[],buf=[];
 function flush(){const t=buf.join(' ').replace(/\s+/g,' ').trim();if(t)out.push({page,section,text:t});buf=[];}
 for(const raw of text.split(/(\f|\r?\n)/)){
  if(raw==='\f'){flush();page++;continue;}
  if(/^\r?\n$/.test(raw)){flush();continue;}
  const line=raw.trim();if(!line)continue;
  const art=line.match(/^art[ií]culo\s+(\d+)\b/i),cl=line.match(/^(\d{1,2}\.\d{1,2})\b/),ann=line.match(/^anexo\s+([a-z])\b/i);
  if(art||cl||ann){flush();section=cl?'CLAUSULA '+cl[1]:art?'ARTICULO '+art[1]:'ANEXO '+ann[1].toUpperCase();}
  if(!/^(DOCUMENTO SIMULADO PARA ENTRENAMIENTO ICEN|Acuerdo Marco de Servicios - Caso ICEN.*Pagina)/i.test(norm(line)))buf.push(line);
 }
 flush();return out;
}
function extract(text,documentId='DOCUMENTO_SIN_ID'){
 const nodes=segment(text);const facts=[];
 for(const n of nodes){
  const t=norm(n.text);
  const topics=Object.entries(TERMS).filter(([,re])=>re.test(t)).map(([k])=>k);
  if(!topics.length)continue;
  const quantities=[...n.text.matchAll(/(?:\$\s*[\d\.]+(?:,\d+)?|\b\d+(?:[,.]\d+)?\s*%|\b\d+\s+d[ií]as?(?:\s+(?:h[aá]biles|corridos|calendario))?)/gi)].map(x=>({raw:x[0],start:x.index}));
  const explicitCondition=/\b(si|siempre que|cuando|s[oó]lo si|en caso de|durante el cual|a condici[oó]n de)\b/i.test(n.text);
  const exception=/\b(salvo|excepto|no aplicar[aá]|sin perjuicio|a excepci[oó]n|derogaci[oó]n espec[ií]fica)\b/i.test(n.text);
  const negation=/\b(no se|no constituye|no podr[aá]|no ser[aá]|no aplica|no operara|no operar[aá])\b/i.test(n.text);
  const actor=/\b(el mandante|el proveedor|las partes|el cliente|el contratista)\b/i.exec(n.text);
  for(const topic of topics){facts.push({id:'F'+String(facts.length+1).padStart(4,'0'),topic,actor:actor?actor[0]:null,conditionPresent:explicitCondition,exceptionPresent:exception,negationPresent:negation,quantities,source:{documentId,page:n.page,section:n.section,quote:n.text},status:'EXTRACCION_CANDIDATA',approved:false});}
 }
 return {schema:'AC-ICEN-M4-GENERALIZACION-02',documentId,nodes:nodes.length,facts,financialExport:{ready:false,reason:'Extracción heurística no validada por revisión humana'},limitations:['No interpreta prioridad jurídica, semántica profunda ni condiciones entre artículos.','Los sujetos y condiciones se detectan por patrones; pueden omitirse o atribuirse incorrectamente.','Los números extraídos no se asocian de forma concluyente con obligaciones.','No existe extracción directa desde PDF ni cálculo financiero.']};
}
module.exports={extract,segment};

};
modules["relaciones"]=function(require,module,exports){
'use strict';
/** AC-ICEN M5: grafo de referencias contractuales, alertas provisionales.
 * No resuelve prevalencias jurídicas ni valida cifras económicamente.
 */
const {extract,segment}=require('./motor_m4');
const norm=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const REFS=[
 {kind:'CLAUSULA',re:/\b(?:art[ií]culo|art\.)\s*(\d{1,2})(?:\.(\d{1,2}))?\b/gi},
 {kind:'ANEXO',re:/\banexo\s+([a-z])\b/gi},
 {kind:'ORDEN',re:/\b(?:orden(?:es)?\s+de\s+servicio\s+)?(OS[-–]\d{2,})\b/gi}
];
function refsFrom(s){const out=[];for(const {kind,re} of REFS){for(const m of s.matchAll(re)){let dest=kind==='CLAUSULA'?(m[2]?`CLAUSULA ${m[1]}.${m[2]}`:`ARTICULO ${m[1]}`):kind==='ANEXO'?`ANEXO ${m[1].toUpperCase()}`:`ORDEN ${m[1].toUpperCase()}`; if(!out.includes(dest))out.push(dest);}}return out;}
function ownArticle(section){let m=section.match(/^(?:ARTICULO|CLAUSULA) (\d+)/);return m?`ARTICULO ${m[1]}`:null;}
function numbers(f){return f.quantities.flatMap(q=>{const raw=norm(q.raw);if(raw.includes('%'))return [{type:'PORCENTAJE',value:Number(raw.replace('%','').replace(',','.').trim()),raw:q.raw}];if(/dias?/.test(raw))return [{type:'DIAS',value:Number(raw.match(/\d+/)?.[0]),raw:q.raw}];if(raw.includes('$'))return [{type:'CLP',value:Number(raw.replace(/[^0-9,]/g,'').replace(/,/g,'.').split('.')[0].length===0?0:raw.replace(/\D/g,'')),raw:q.raw}];return []})}
function analyze(text,documentId='DOCUMENTO_SIN_ID'){
 const base=extract(text,documentId), all=segment(text);const sections=new Map();
 for(const n of all){if(!sections.has(n.section))sections.set(n.section,[]);sections.get(n.section).push(n)}
 const edges=[],warnings=[],facts=base.facts.map(f=>({...f,links:[],reviewRequired:true}));
 const index=new Map();for(const f of facts){if(!index.has(f.source.section))index.set(f.source.section,[]);index.get(f.source.section).push(f)}
 const byArt=new Map();for(const f of facts){const a=ownArticle(f.source.section);if(a){if(!byArt.has(a))byArt.set(a,[]);byArt.get(a).push(f)}}
 const unique=new Set();
 for(const f of facts){for(const ref of refsFrom(f.source.quote)){
   // A clause referring to itself is not a dependency.
   if(ref===f.source.section||ref===ownArticle(f.source.section))continue;
   const targets=index.get(ref)||byArt.get(ref)||[];
   const key=`${f.id}/${ref}`;if(unique.has(key))continue;unique.add(key);
   const edge={kind:'REFERENCIA_EXPRESA',from:f.id,to:ref,resolved:targets.length>0,targetFactIds:targets.map(t=>t.id),evidence:f.source,legalPriorityDetermined:false};edges.push(edge);f.links.push(edge);
 }}
 // Compare only like-for-like measures in the same topic across different clauses.
 // This is merely an alert for a reviewer; whether the scopes overlap is unknown.
 for(let i=0;i<facts.length;i++)for(let j=i+1;j<facts.length;j++){
   const a=facts[i],b=facts[j];if(a.topic!==b.topic||a.source.section===b.source.section)continue;
   const av=numbers(a),bv=numbers(b);const differing=[];
   for(const x of av)for(const y of bv)if(x.type===y.type&&Number.isFinite(x.value)&&Number.isFinite(y.value)&&x.value!==y.value)differing.push({type:x.type,left:x.raw,right:y.raw});
   if(!differing.length)continue;
   // Repeated mentions create many false positives. Keep only alerts for shared topic with differentiating numbers;
   // cap volume per topic while retaining the complete evidence for each emitted alert.
   const qualifier=/\b(salvo|excepto|especial|especific|unicamente|solo|urgente|derogacion|prevalec|cuando|siempre que)\b/.test(norm(a.source.quote+' '+b.source.quote));
   const k=[a.topic,a.source.section,b.source.section].join('/');if(warnings.some(w=>w.dedupKey===k))continue;
   if(warnings.filter(w=>w.topic===a.topic).length>=12)continue;
   warnings.push({id:`A${String(warnings.length+1).padStart(3,'0')}`,dedupKey:k,kind:qualifier?'POSIBLE_REGLA_ESPECIAL_O_AMBITO_DISTINTO':'DIFERENCIA_A_REVISAR',topic:a.topic,measureDifferences:differing.slice(0,4),factIds:[a.id,b.id],sources:[a.source,b.source],outcome:'NO_RESUELTO',humanReview:true,reason:'Los valores difieren, pero no se ha verificado igualdad de supuesto, vigencia ni jerarquía documental.'});
 }
 return {schema:'AC-ICEN-M5-RELACIONES-01',documentId,nodes:base.nodes,facts,edges,warnings,coverage:{candidateFacts:facts.length,explicitReferences:edges.length,potentialDifferences:warnings.length},financialExport:{ready:false,approvedFacts:[],reason:'No hay interpretación jurídica ni aprobación humana. No exportar importes ni plazos a cálculos.'},limitations:[...base.limitations,'El enlace explícito se detecta por expresiones regulares y puede asociar referencias al artículo equivocado.','Las diferencias numéricas generan alertas no resueltas; nunca se etiquetan como contradicciones confirmadas.','No identifica equivalencia semántica ni dependencia transversal sin referencia expresa.','La cobertura de las alertas se limita a 12 pares por materia para evitar inundación.']};
}
module.exports={analyze,refsFrom,numbers};

};
modules["nucleo_m6"]=function(require,module,exports){
'use strict';
/** M6: candidate rule model (not legal adjudication). Uses M5 extraction; no file mutation. */
const {analyze}=require('./relaciones');
const {segment}=require('./motor_m4');
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const reg={
  condition:/\b(si|siempre que|cuando|en caso de|durante el cual|sujeto a|solo si|una vez que)\b/i,
  except:/\b(salvo|excepto|a excepcion de|no operara|no se aplicara|sin perjuicio|excluid[oa]s?)\b/i,
  scope:/\b(especial|especific[oa]|critic[oa]|urgente|exclusivamente|unicamente)\b/i,
  override:/\b(derogacion especifica|prevalec|jerarquia|prelacion|modificar)\b/i,
  obligation:/\b(debera|debe|pagara|estara obligado|no excedera|se devenga|se aplicara|podra terminar|se entendera aceptada)\b/i
};
const has=(s,re)=>re.test(norm(s));
const evidence=(f)=>({documentId:f.source.documentId,page:f.source.page,section:f.source.section,quote:f.source.quote});
function analyzeM6(text,documentId='DOCUMENTO_SIN_ID'){
 const base=analyze(text,documentId);
 const rules=base.facts.map(f=>{
   const quote=f.source.quote, q=norm(quote);
   const tags={condition:has(q,reg.condition),exception:has(q,reg.except),specialScope:has(q,reg.scope),hierarchy:has(q,reg.override),obligation:has(q,reg.obligation)};
   const scopeTags=[...new Set([/\bcritic[oa]\b/.test(q)?'RECURSO_CRITICO':null,/\burgente\b/.test(q)?'ORDEN_URGENTE':null,/\borden(?:es)? de servicio\b/.test(q)?'ORDEN_SERVICIO':null,/\bprimeros?\s+(?:3|tres)\s+meses\b/.test(q)?'PRIMEROS_TRES_MESES':null].filter(Boolean))];
   return {id:`R-${f.id}`,topic:f.topic,actorCandidate:f.actor,kind:tags.hierarchy?'JERARQUIA_CANDIDATA':tags.exception?'EXCEPCION_CANDIDATA':tags.condition?'CONDICIONAL_CANDIDATA':tags.obligation?'OBLIGACION_CANDIDATA':'MENCION_CANDIDATA',tags,scopeTags,quantities:f.quantities,source:evidence(f),reviewRequired:true,approved:false};
 });
 // Restore topic context from the article heading for numbered clauses whose text omits the topic name.
 const segs=segment(text), headingTopics=new Map();
 const headingTerms=[['credito_servicio',/creditos? de servicio/i],['pago',/pagos?|facturaci[oó]n/i],['garantia',/garant[ií]as?/i],['responsabilidad',/responsabilidad/i],['orden',/orden(?:es)? de servicio/i]];
 let currentArticle=null;
 for(const seg of segs){
   const a=seg.section.match(/^ARTICULO (\d+)/), c=seg.section.match(/^CLAUSULA (\d+)\./);
   if(a){currentArticle=a[1];for(const [topic,re] of headingTerms)if(re.test(norm(seg.text)))headingTopics.set(currentArticle,topic);}
   if(c&& !rules.some(r=>r.source.page===seg.page&&r.source.section===seg.section&&r.source.quote===seg.text)){
      const topic=headingTopics.get(c[1]);
      if(topic && /\d+\s*%|\d+\s*d[ií]as?|\$\s*[\d.]+/.test(seg.text)){
       const q=norm(seg.text),tags={condition:has(q,reg.condition),exception:has(q,reg.except),specialScope:has(q,reg.scope),hierarchy:has(q,reg.override),obligation:has(q,reg.obligation)};
       rules.push({id:`R-CONTEXTO-${rules.length+1}`,topic,actorCandidate:null,kind:'CLAUSULA_CONTEXTO_CANDIDATA',tags,scopeTags:/\bcritic[oa]\b/.test(q)?['RECURSO_CRITICO']:[],quantities:[...seg.text.matchAll(/\d+(?:[.,]\d+)?\s*%|\d+\s+d[ií]as?|\$\s*[\d.]+/gi)].map(m=>({raw:m[0],start:m.index})),source:{documentId,page:seg.page,section:seg.section,quote:seg.text},reviewRequired:true,approved:false});
      }
   }
 }
 const relationAlerts=base.warnings.map(w=>({id:w.id,type:w.kind,topic:w.topic,source:w.sources,outcome:'PENDIENTE_REVISION',reason:w.reason}));
 // Cross-document hierarchy is a prerequisite check, not a definitive decision.
 const pageFacts=(...terms)=>rules.filter(r=>terms.every(t=>norm(r.source.quote).includes(norm(t))));
 const observations=[];
 const make=(code,label,arr,reason)=>{if(arr.length)observations.push({code,label,status:'REVISION_REQUERIDA',source:arr.slice(0,8).map(r=>r.source),reason});};
 // Generic trigger relationships (no contract identifiers or predetermined numeric answers).
 make('ACTIVACION_ORDEN','Regla de activación por orden',rules.filter(r=>r.topic==='orden'&&(r.tags.condition||/\baceptad|\bactiva|\bemitid|\breserv/.test(norm(r.source.quote)))),'Verificar aceptación efectiva, vigencia y recursos reservados antes de reconocer ingresos.');
 make('EXCEPCIONES','Excepciones o exclusiones expresas',rules.filter(r=>r.tags.exception),'Distinguir exclusión real, condición y alcance temporal; no resolver precedencia automáticamente.');
 make('PRELACION','Prelación o derogación documental',rules.filter(r=>r.tags.hierarchy),'Comparar requisito formal de derogación con contenido y nivel del documento citado.');
 // Detect issue when identical topic has different percentages but scope differs, including from same Article.
 for(const topic of ['credito_servicio','pago','responsabilidad','garantia']){
  const rr=rules.filter(r=>r.topic===topic);
  const values=new Set(rr.flatMap(r=>r.quantities.filter(q=>/%/.test(q.raw)).map(q=>q.raw.match(/\d+(?:[.,]\d+)?/)?.[0]?.replace(',','.')).filter(Boolean)));
  if(values.size>1){const scoped=rr.some(r=>r.tags.specialScope||r.tags.exception);make('PORCENTAJES_'+topic.toUpperCase(),`Diferentes porcentajes en ${topic}`,rr.filter(r=>r.quantities.some(q=>q.raw.includes('%'))),scoped?'Puede existir regla general y ámbito especial; comparar sujeto, base y evento.':'Comparar bases y supuestos antes de concluir conflicto.');}
 }
 // Multiple payment deadlines only if payment statements actually contain days.
 const payments=rules.filter(r=>r.topic==='pago'&&r.quantities.some(q=>/d[ií]as/i.test(q.raw)));
 const days=new Set(payments.flatMap(r=>r.quantities.filter(q=>/d[ií]as/i.test(q.raw)).map(q=>q.raw.match(/\d+/)?.[0])).filter(Boolean));
 if(days.size>1)make('PLAZOS_PAGO','Diferentes plazos asociados a pagos',payments,'Revisar si los plazos son vencimiento de factura, mora, validación, orden o terminación: no equipararlos sin contexto.');
 return {schema:'AC-ICEN-M6-NUCLEO-01',documentId,coverage:{candidateFacts:base.facts.length,ruleCandidates:rules.length,explicitReferences:base.edges.length,relationAlerts:relationAlerts.length,issueGroups:observations.length},rules,edges:base.edges,relationAlerts,observations,financialExport:{ready:false,approvedFacts:[],reason:'No está resuelta la validez jurídica ni las variables cuantitativas; exige revisión humana.'},limitations:['Clasificación basada en patrones y coocurrencia, no interpretación jurídica autónoma.','Una frase puede contener varias reglas y el programa puede unir sujetos, cantidades o ámbitos indebidamente.','No comprueba autenticidad documental, contratos completos ni documentos sustituidos.','Detectar distintos porcentajes o plazos no prueba contradicción ni prioridad.','M6 no calcula rentabilidad ni transmite variables a la calculadora.']};
}
module.exports={analyzeM6};

};
modules["motor_m7"]=function(require,module,exports){
'use strict';
/**
 * AC-ICEN M7.01 — contracts under Chilean commercial law: evidence-first candidate analyzer.
 * Experimental. Does not issue binding legal opinions or claim normative verification.
 * Read-only, offline, deterministic. No network and no financial export.
 */
const {analyzeM6}=require('./nucleo_m6');
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const contains=(s,re)=>re.test(norm(s));
const checks=[
 ['FORMACION_ORDEN',/\borden(?:es)? de servicio\b|\borden(?:es)? de compra\b/,/\baceptad|\bactiv|\bemitid|\bsilencio|\bsolicit/],
 ['EXCEPCIONES',/\bsalvo\b|\bexcepto\b|\bno operara\b|\bsin perjuicio\b|\ba excepcion\b/,null],
 ['JERARQUIA',/\bderogacion especifica\b|\bprevalec|\bprelacion\b|\bjerarquia\b/,null],
 ['PAGOS',/\bpago\b|\bfacturaci[oó]n\b|\bfactura\b/,/\bdias?\b|\bplazo\b/],
 ['GARANTIAS',/\bgarantia\b|\bboleta\b|\bpoliza\b/,null],
 ['RESPONSABILIDAD',/\bresponsabilidad\b|\bindemnizaci[oó]n\b/,null],
 ['CREDITOS_SERVICIO',/\bcreditos? de servicio\b|\bsla\b|\bniveles? de servicio\b/,null]
];
const actionRe=/\b(debera|pagara|estara obligado|debe|se devenga|se entendera|podra|ser[aá] exigible)\b/i;
const exceptions=/\b(salvo|excepto|siempre que|unicamente|solo si|no operara|condicionad[oa])\b/i;
const controlQuestions={
 FORMACION_ORDEN:'¿Consta emisión, aceptación, vigencia y condición de activación de la orden?',
 EXCEPCIONES:'¿A qué regla, sujeto y supuesto se aplica la excepción?',
 JERARQUIA:'¿Se cumplieron las formalidades contractuales para modificar la cláusula?',
 PAGOS:'¿Cuál es el hecho que inicia el cómputo del plazo y cuál es el documento aplicable?',
 GARANTIAS:'¿La garantía implica inmovilización de efectivo o un instrumento diferente?',
 RESPONSABILIDAD:'¿Qué base de cálculo, exclusiones y período se aplican?',
 CREDITOS_SERVICIO:'¿Los porcentajes corresponden a ámbitos y bases comparables?'
};
function analyzeM7(input){
 if(!input||!Array.isArray(input.documents)||!input.documents.length)throw Error('Se requiere documents no vacío');
 const ids=input.documents.map(d=>d.id);
 if(ids.some(x=>typeof x!=='string'||!x.trim())||new Set(ids).size!==ids.length)throw Error('ID documental único obligatorio');
 const docs=input.documents.map(d=>{
  if(typeof d.text!=='string'||!d.text.trim())throw Error('Texto contractual obligatorio');
  const base=analyzeM6(d.text,d.id);
  const clauses=base.rules.map(r=>{
   const txt=r.source.quote;
   const matters=checks.filter(([,a,b])=>contains(txt,a)&&(!b||contains(txt,b))).map(([c])=>c);
   return {id:r.id,documentId:d.id,section:r.source.section,page:r.source.page,evidence:txt,
    subjectCandidate:r.actorCandidate||null,kindCandidate:r.kind,matters,
    flags:{condition:r.tags.condition,exception:r.tags.exception,priority:r.tags.hierarchy,obligation:contains(txt,actionRe)},
    numbers:r.quantities,confidence:'NO_CALIBRADA',legalConclusion:null};
  });
  return {id:d.id,type:d.type||'NO_DECLARADO',clauses,baseObservations:base.observations,baseCoverage:base.coverage};
 });
 const all=docs.flatMap(x=>x.clauses);
 const issues=[];
 for(const [code,,] of checks){
  const relevant=all.filter(c=>c.matters.includes(code));
  if(relevant.length)issues.push({id:'REVISION_'+code,matter:code,classification:'PENDIENTE_ANALISIS',
   verificationQuestion:controlQuestions[code],evidence:relevant.slice(0,12).map(c=>({documentId:c.documentId,page:c.page,section:c.section,quote:c.evidence})),
   verifiedLegalRule:false,legalConclusion:null});
 }
 // A missing issue does not prove absence. No 'pass' status without external legal validation.
 return {schema:'AC-ICEN-M7-CHILE-01',jurisdiction:'CL',scope:'CONTRATOS_COMERCIALES_EMPRESARIALES',
  status:'EXPERIMENTAL_PENDIENTE_VALIDACION_JURIDICA',documents:docs,issues,
  sources:{contractEvidence:true,legalNormsVerified:[],caseLawVerified:[],normativeResearchRequired:true},
  safety:{automaticLegalAdvice:false,financialExportAllowed:false,humanReviewRequired:true,
   neverUseToDetermineEnforceability:true},
  coverage:{documentCount:docs.length,candidateClauseCount:all.length,issueCategories:issues.length},
  limitations:['No hay consulta de legislación ni jurisprudencia; no es un dictamen legal.',
   'Detecta candidatos por patrones; puede omitir artículos que no repiten la materia.',
   'No resuelve jerarquía documental, aplicabilidad jurídica, validez ni contradicciones por sí mismo.',
   'Las citas a documentos deben corroborarse visualmente con sus originales.']};
}
module.exports={analyzeM7};

};
function req(n){n=n.replace(/^\.\//,"");if(!modules[n])throw Error("Módulo no encontrado: "+n);if(!cache[n]){let m={exports:{}};cache[n]=m;modules[n](req,m,m.exports);}return cache[n].exports;}return req("motor_m7");})();