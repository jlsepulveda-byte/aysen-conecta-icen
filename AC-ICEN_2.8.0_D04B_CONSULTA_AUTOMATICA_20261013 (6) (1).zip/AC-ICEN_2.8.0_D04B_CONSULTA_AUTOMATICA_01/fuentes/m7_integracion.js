'use strict';
/** AC-ICEN 2.8.0 · Integración lector documental + Evaluador Contractual M7 en «Análisis de la contraparte».
 *  Aditivo: no elimina funciones de 2.7.0; redefine mvAdd y envuelve mvRun, mvClear y mvSend. */
const M7S={res:null,docs:[],alerts:[],obs:[],evs:[],rev:{},err:null,msgs:[]};
const M7_BLOQUEO={pago:['c_pay','c_retDays','c_adv','c_ret'],credito_servicio:['c_pen'],PLAZOS_PAGO:['c_pay','c_retDays','c_adv','c_ret'],PORCENTAJES_CREDITO_SERVICIO:['c_pen']};
const M7_ETQ={c_pay:'plazo de pago pactado',c_retDays:'liberación de retención',c_adv:'anticipo',c_ret:'retención',c_pen:'exposición a multa'};
const m7e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function m7Reflow(raw){return raw.replace(/\f/g,'\n').replace(/\n(?!\s*(?:\d{1,2}\.\d{1,2}\s|Art[íi]culo\s+\d+|ANEXO\s+[A-Z]\b|\d{1,2}\.\s+[A-ZÁÉÍÓÚ]|PARTE\s+[IVX]+\b))/g,' ')}
function m7Doc(name,raw,extra){const csv=MVE.kind(raw)==='csv';return Object.assign({name,t:csv?raw:'Documento importado\n'+m7Reflow(raw),raw,pages:raw.split('\f'),paginado:raw.includes('\f'),tipo:'TXT',sha:null,h:'—'},extra||{})}
async function mvAdd(files){M7S.msgs=[];
 for(const f of Array.from(files)){try{const d=await LECTOR.leer(f);
   if(d.sha256&&MV.docs.some(x=>x.sha===d.sha256)){M7S.msgs.push(f.name+': ya estaba cargado (misma huella SHA-256).');continue}
   MV.docs.push(m7Doc(f.name,d.raw,{pages:d.pages,paginado:d.paginado,tipo:d.type,sha:d.sha256,h:(d.sha256||'—').slice(0,12)}))}
  catch(e){M7S.msgs.push(f.name+': '+e.message)}}
 mvRun()}
function m7LoadMaster(){MV.docs=MV.docs.filter(d=>d.name!=='contrato_maestro_caso_2027_211.txt');MV.docs.push(m7Doc('contrato_maestro_caso_2027_211.txt',M7_MASTER,{h:'muestra'}));mvRun()}
function m7Pag(id,p){const d=M7S.docs.find(x=>x.id===id);return d&&d.src.paginado?'página '+p:'página no disponible (formato sin paginación)'}
function m7Ev(e){const k=M7S.evs.push(e)-1;return '<div class="small"><b>'+m7e(e.documentId)+'</b> · '+m7Pag(e.documentId,e.page)+' · '+m7e(e.section)+'</div><blockquote style="margin:6px 0;padding:8px 10px;border-left:3px solid #116e65;background:#f5f8f7;font-size:13px">'+m7e(e.quote.length>320?e.quote.slice(0,320)+'…':e.quote)+'</blockquote><button class="btn secondary sm" onclick="m7View('+k+')">Ver en el documento original</button>'}
function m7Locate(raw,quote){const map=[];let c='';for(let i=0;i<raw.length;i++){if(/\s/.test(raw[i])){if(c&&!c.endsWith(' ')){c+=' ';map.push(i)}}else{c+=raw[i];map.push(i)}}
 const q=quote.replace(/\s+/g,' ').trim();let n=q.length,at=c.indexOf(q);if(at<0){n=Math.min(60,q.length);at=c.indexOf(q.slice(0,n))}if(at<0)return null;return{s:map[at],e:map[at+n-1]+1}}
function m7View(k){const e=M7S.evs[k],d=M7S.docs.find(x=>x.id===e.documentId),v=document.getElementById('m7Viewer');if(!d){return}
 const loc=m7Locate(d.text,e.quote);if(!loc){v.innerHTML='<p class="small">No se pudo ubicar el fragmento exacto en el texto leído. Fragmento citado: '+m7e(e.quote)+'</p>';return}
 const a=Math.max(0,loc.s-300),b=Math.min(d.text.length,loc.e+300),pg=(d.text.slice(0,loc.s).match(/\f/g)||[]).length+1;
 v.innerHTML='<div class="small" style="margin-bottom:6px"><b>'+m7e(d.id)+'</b> · '+(d.src.paginado?'página '+pg:'página no disponible')+' · '+m7e(e.section)+'</div><div style="white-space:pre-wrap;font:13px/1.5 ui-monospace,Consolas,monospace;background:#f7f9f8;border:1px solid #d5e1dc;border-radius:12px;padding:12px;max-height:280px;overflow:auto">'+m7e(d.text.slice(a,loc.s)).replace(/\f/g,'\n— salto de página —\n')+'<mark style="background:#ffe08a">'+m7e(d.text.slice(loc.s,loc.e))+'</mark>'+m7e(d.text.slice(loc.e,b)).replace(/\f/g,'\n— salto de página —\n')+'</div>';v.scrollIntoView({behavior:'smooth',block:'nearest'})}
function m7Run(){const docs=MV.docs.filter(d=>{const k=MVE.kind(d.raw||d.t);return k==='txt'||k==='fin'});
 M7S.evs=[];M7S.err=null;
 if(!docs.length){M7S.res=null;M7S.docs=[];M7S.alerts=[];M7S.obs=[];m7Render();return}
 const used=new Set(),ds=docs.map(d=>{let id=d.name,k=2;while(used.has(id))id=d.name+' ('+k+++')';used.add(id);return{id,type:'CONTRATO',text:d.raw||d.t,src:d}});
 try{M7S.res=ICEN.analyzeM7({documents:ds.map(({id,type,text})=>({id,type,text}))});M7S.docs=ds;
  const a=ds.map(x=>ICEN.analyzeM6(x.text,x.id));M7S.alerts=a.flatMap(x=>x.relationAlerts);M7S.obs=a.flatMap((x,i)=>x.observations.map(o=>({...o,docId:ds[i].id})))}
 catch(e){M7S.res=null;M7S.err=e.message}
 m7Render()}
function m7Revisada(id){return M7S.rev[id]==='revisada'||M7S.rev[id]==='descartada'}
function m7Blocked(){const s=new Set();
 M7S.alerts.forEach(a=>{if(!m7Revisada(a.id))(M7_BLOQUEO[a.topic]||[]).forEach(x=>s.add(x))});
 M7S.obs.forEach((o,i)=>{if(!m7Revisada('OBS'+i))(M7_BLOQUEO[o.code.replace(/^PORCENTAJES_(.*)$/,'PORCENTAJES_$1')]||[]).forEach(x=>s.add(x))});return[...s]}
function m7Rev(id,v){M7S.rev[id]=v;m7Guard()}
function m7Sel(id){const v=M7S.rev[id]||'';return '<label class="small">Revisión humana: <select onchange="m7Rev(\''+id+'\',this.value)" style="padding:6px;border-radius:8px;border:1px solid #b9cbc4"><option value="">Sin revisar</option><option value="revisada"'+(v==='revisada'?' selected':'')+'>Revisada por una persona</option><option value="descartada"'+(v==='descartada'?' selected':'')+'>Descartada: no es un conflicto</option></select></label>'}
function m7Guard(){const el=document.getElementById('m7Guard');if(!el)return;const b=m7Blocked();
 el.innerHTML='<b>Transferencia a la calculadora:</b> ninguna conclusión jurídica del evaluador M7 pasa a la Calculadora ICEN. '+(b.length?'Además, estos valores quedan retenidos hasta que una persona revise los hallazgos relacionados: <b>'+b.map(x=>M7_ETQ[x]).join(', ')+'</b>.':'No hay valores retenidos por hallazgos sin revisar.')}
function m7Render(){const o=document.getElementById('m7Out');if(!o)return;M7S.evs=[];const R=M7S.res;let h='';
 if(M7S.msgs.length)h+='<div class="section accent-panel" role="alert">'+M7S.msgs.map(m7e).join('<br>')+'</div>';
 if(M7S.err)h+='<div class="section accent-panel" role="alert"><b>Evaluador M7:</b> '+m7e(M7S.err)+'</div>';
 if(!R){o.innerHTML=h;return}
 h+='<div class="card" style="margin-top:16px"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><h2 style="margin:0">Evaluador contractual M7</h2><span class="badge warn">Prototipo experimental · pendiente de validación jurídica</span></div><p>'+R.coverage.candidateClauseCount+' cláusulas candidatas en '+R.coverage.documentCount+' documento(s) · '+R.coverage.issueCategories+' materias señaladas · '+M7S.alerts.length+' diferencias entre cláusulas. Ningún hallazgo es una conclusión jurídica: son puntos que una persona debe revisar contra el documento original.</p><div id="m7Guard" class="section accent-panel"></div></div>';
 h+='<div class="card" style="margin-top:16px"><h2>Diferencias entre cláusulas a revisar</h2>'+(M7S.alerts.length?M7S.alerts.map(a=>'<div class="status" style="display:block"><b>'+m7e(a.topic.replace(/_/g,' '))+'</b> <span class="badge warn">Ambigua</span><div class="small muted">'+m7e(a.reason)+' Los valores difieren, pero no se verificó si aplican al mismo supuesto, vigencia o jerarquía.</div>'+a.source.map(m7Ev).join('')+m7Sel(a.id)+'</div>').join(''):'<p>No se detectaron diferencias numéricas entre cláusulas con las reglas actuales. Esto no implica ausencia de riesgos.</p>')+'</div>';
 h+='<div class="card" style="margin-top:16px"><h2>Observaciones estructurales</h2>'+(M7S.obs.length?M7S.obs.map((x,i)=>'<div class="status" style="display:block"><b>'+m7e(x.label)+'</b> <span class="badge warn">Requiere revisión</span><div class="small muted">'+m7e(x.reason)+' · '+m7e(x.docId)+'</div>'+x.source.slice(0,3).map(m7Ev).join('')+m7Sel('OBS'+i)+'</div>').join(''):'<p>Sin observaciones estructurales.</p>')+'</div>';
 h+='<div class="card" style="margin-top:16px"><h2>Materias señaladas</h2>'+R.issues.map(i=>'<details class="status" style="display:block"><summary><b>'+m7e(i.matter.replace(/_/g,' '))+'</b> <span class="badge warn">Requiere revisión</span> <span class="small muted">'+i.evidence.length+' fragmento(s)</span></summary><p>'+m7e(i.verificationQuestion)+'</p>'+i.evidence.slice(0,4).map(m7Ev).join('')+'</details>').join('')+'</div>';
 h+='<div class="card" style="margin-top:16px"><h2>Visor del documento original</h2><div id="m7Viewer" class="small muted">Pulse «Ver en el documento original» en cualquier hallazgo para ubicar el fragmento con su página y sección.</div></div>';
 h+='<div class="card" style="margin-top:16px"><h3>Límites declarados por el evaluador</h3><ul>'+R.limitations.map(l=>'<li class="small">'+m7e(l)+'</li>').join('')+'<li class="small">La página solo se informa para PDF y para archivos con saltos de página; en TXT y DOCX sin saltos no está disponible.</li></ul></div>';
 o.innerHTML=h;m7Guard()}
const _mvRun=mvRun;mvRun=function(){_mvRun();m7Run()};
const _mvClear=mvClear;mvClear=function(){_mvClear();M7S.res=null;M7S.rev={};M7S.msgs=[];m7Render()};
const _mvSend=mvSend;mvSend=function(){const ok=document.getElementById('mvConfirm')&&document.getElementById('mvConfirm').checked,b=ok?m7Blocked():[],prev={};
 b.forEach(i=>{prev[i]=document.getElementById(i).value});_mvSend();if(!ok)return;
 b.forEach(i=>{document.getElementById(i).value=prev[i];delete MV.src[i]});
 if(M7S.res)MV.src.m7='Evaluador M7: ninguna conclusión jurídica se transfirió a la calculadora.'+(b.length?' Valores retenidos hasta su revisión humana: '+b.map(x=>M7_ETQ[x]).join(', ')+'.':'');
 calc()};
