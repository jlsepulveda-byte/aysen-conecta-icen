# -*- coding: utf-8 -*-
"""Servidor local ICEN D04-A, Python stdlib; sin dependencias externas."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse,parse_qs
import sqlite3,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'juridica'/'icen_juridica.sqlite'
MATERIAS={'PAGOS':'plazos_pago','PLAZOS_PAGO':'plazos_pago','plazos_pago':'plazos_pago'}
class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
 def do_GET(self):
  u=urlparse(self.path)
  if u.path=='/api/juridica/consulta':
   q=parse_qs(u.query);materia=(q.get('materia') or [''])[0]
   normal=MATERIAS.get(materia,'')
   fecha=(q.get('fecha_contrato') or [''])[0]
   if fecha and not __import__('re').fullmatch(r'\d{4}-\d{2}-\d{2}',fecha):
    return self.send_json({'materia':materia,'registros':[],'estado':'FECHA_INVALIDA','advertencia':'Fecha no válida. Debe ser AAAA-MM-DD.'})
   if not normal:
    return self.send_json({'materia':materia,'registros':[],'estado':'SIN_COBERTURA_NORMATIVA','advertencia':'No hay artículos incorporados para esta materia.'})
   with sqlite3.connect(DB) as cx:
    cx.row_factory=sqlite3.Row
    rows=[dict(r) for r in cx.execute('select * from normas where materia=? order by norma,articulo',(normal,))]
   return self.send_json({'materia':materia,'fecha_contrato':fecha,'vigencia_verificada':False,'registros':rows,'estado':'REFERENCIAS_CANDIDATAS','advertencia':'El catálogo contiene referencias verificadas a fuentes oficiales, NO textos legales validados por versión histórica ni conclusiones jurídicas. Comprobar el texto y la vigencia para la fecha del contrato.'})
  return super().do_GET()
 def send_json(self,obj):
  b=json.dumps(obj,ensure_ascii=False).encode('utf-8');self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(b)
if __name__=='__main__':
 import webbrowser,threading,time
 s=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
 threading.Thread(target=lambda:(time.sleep(0.8),webbrowser.open('http://127.0.0.1:8765/AC-ICEN-MVP_2.8.0_20261013_PROPUESTA.html')),daemon=True).start()
 print('ICEN D04-A disponible en http://127.0.0.1:8765/');s.serve_forever()
