# INFORME DE PRUEBAS · AC-ICEN-MVP 2.8.0 PROPUESTA
Fecha: 2026-10-13 · Entorno: Chromium 141 (Playwright) abriendo el HTML por `file://`, igual que en Windows; Node 22 para pruebas unitarias.

## Resultado
| Prueba | Resultado |
|---|---|
| Pruebas originales del módulo M7 (`fuentes/test_m7.js`) | 14 de 14 aprobadas |
| Pruebas de generalización (`fuentes/test_generalizacion.js`) | 6 de 6 aprobadas |
| Extremo a extremo en navegador (`pruebas/e2e_2_8_0.js`) | 37 de 37 aprobadas |
| Sintaxis de todos los bloques de script | Sin errores (carga sin excepciones ni mensajes de error de consola) |
Registros completos: `pruebas/RESULTADOS_unitarias_M7.txt` y `pruebas/RESULTADOS_E2E.txt`.

## Auditoría de navegación (Instrucción §9.6)
- 55 pantallas conservadas (`section.screen`), igual que en 2.7.0.
- 0 destinos `go('…')` inexistentes. Las 55 pantallas se abren con `go()`.
- 0 botones con `onclick` que apunten a una función inexistente.
- Base canónica 2.7.0 verificada por SHA-256: intacta.

## Qué se probó con archivos
PDF del caso maestro (18 páginas), PDF generado con ReportLab (4 páginas), PDF generado por LibreOffice desde DOCX, DOCX con tabla, TXT, PDF sin texto, PDF corrupto y archivo con extensión .docx falsa. Los defectuosos muestran un mensaje comprensible y no se cargan.

## Prueba con el contrato maestro (Instrucción §5)
Lectura de las 18 páginas, 65 cláusulas candidatas, 6 materias señaladas, 5 observaciones estructurales y 3 diferencias entre cláusulas, cada una con documento, página, sección y fragmento. Ningún encabezado de página entra como cláusula.

## Límites y fallos detectados (no ocultar)
1. **La detección de M7 es parcial.** De 10 reglas o tensiones del caso maestro, solo 4 aparecen como fragmento dentro de una materia (responsabilidad 30 %, tope de créditos 12 % frente a 15 %, plazo de pago 30 frente a 45 días, combustible 8 % frente a 10 %) y 6 no aparecen: aceptación provisional frente a certificación total, bonificación automática frente a condicionada, derogación específica y prelación, Cargo Base prorrateado frente a indivisible, arbitraje frente a tribunales de Coyhaique, y monto anual que no es ingreso asegurado.
2. **Solo 1 de las 3 diferencias detectadas corresponde a una tensión real** (combustible, cláusulas 5.3 y 5.4). Las otras dos (pago 7.4 frente a Anexo C; garantía 17.1 frente a 17.2) comparan cláusulas que no son equivalentes. Por eso se presentan como «Ambigua» y exigen revisión humana.
3. M7 no distingue regla general de excepción, ni qué evento inicia un plazo, ni resuelve prelaciones. Sigue siendo extracción por patrones.
4. El motor numérico de 2.7.0 no se modificó: sobre el caso maestro puede omitir datos (por ejemplo, el plazo general de pago de 30 días).
5. Sin OCR: los PDF escaneados no se leen. La página no está disponible en TXT ni en DOCX sin saltos de página.
6. El DOCX se lee desde su XML: no interpreta cuadros de texto, notas al pie ni cambios con control de cambios.
7. Las pruebas de navegador se ejecutaron en Chromium. No se probó en Edge ni en Firefox, ni en un equipo Windows real.
8. Archivo de ~2 MB por incluir los lectores locales; contradice en parte la preferencia por páginas livianas (Reglas §25). Alternativa propuesta: carga diferida desde archivos separados con un servidor local.

## Cómo repetir las pruebas
`node fuentes/test_m7.js` y `node fuentes/test_generalizacion.js` (solo Node). Para el navegador: `npm install playwright`, `npx playwright install chromium` y `node pruebas/e2e_2_8_0.js`. El HTML se regenera con `python construir_2_8_0.py`.
