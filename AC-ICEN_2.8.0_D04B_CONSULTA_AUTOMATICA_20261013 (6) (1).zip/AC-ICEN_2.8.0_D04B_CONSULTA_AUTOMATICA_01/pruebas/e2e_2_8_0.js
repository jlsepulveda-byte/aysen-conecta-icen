'use strict';
// Pruebas de extremo a extremo en Chromium real, abriendo el HTML por file:// (como en Windows).
const {chromium}=require('playwright');const path=require('path');const fs=require('fs');const crypto=require('crypto');
const ROOT=path.resolve(__dirname,'..'),APP=path.join(ROOT,'AC-ICEN-MVP_2.8.0_20261013_PROPUESTA.html'),FX=p=>path.join(__dirname,'fixtures',p),CASO=path.join(ROOT,'casos','AC-ICEN_CASO_MAESTRO_CONTRATO_2_0.pdf');
let ok=0,fail=0;const t=(n,c,d)=>{if(c){ok++;console.log('OK   '+n)}else{fail++;console.log('FALLA '+n+(d?' → '+d:''))}};
(async()=>{
 const b=await chromium.launch();const ctx=await b.newContext({acceptDownloads:true});const p=await ctx.newPage();const errs=[];
 p.on('pageerror',e=>errs.push('pageerror: '+e.message));p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text())});p.on('dialog',d=>{errs.push('dialog: '+d.message());d.dismiss()});
 await p.goto('file://'+APP);await p.waitForTimeout(500);
 t('carga sin errores de consola ni excepciones',errs.length===0,errs.join(' | '));
 // 1) integridad y navegación
 const nav=await p.evaluate(()=>{const ids=[...document.querySelectorAll('section.screen')].map(x=>x.id);const html=document.documentElement.innerHTML;const tg=new Set([...html.matchAll(/go\('([^']+)'/g)].map(m=>m[1]));return{n:ids.length,ids,faltan:[...tg].filter(x=>!ids.includes(x))}});
 t('55 pantallas conservadas',nav.n===55,'hay '+nav.n);t('cero destinos go() inexistentes',nav.faltan.length===0,nav.faltan.join(','));
 const vis=await p.evaluate(async ids=>{const bad=[];for(const id of ids){try{go(id);await new Promise(r=>setTimeout(r,20));const e=document.getElementById(id);if(!e||getComputedStyle(e).display==='none')bad.push(id)}catch(x){bad.push(id+':'+x.message)}}go('public');return bad},nav.ids);
 t('las 55 pantallas se pueden abrir con go()',vis.length===0,vis.join(','));
 const btn=await p.evaluate(()=>{const bad=[];document.querySelectorAll('button[onclick]').forEach(x=>{const m=/^(\w+)\(/.exec(x.getAttribute('onclick'));if(m&&typeof window[m[1]]!=='function')bad.push(m[1])});return[...new Set(bad)]});
 t('todo botón con onclick apunta a una función existente',btn.length===0,btn.join(','));
 t('canónica 2.7.0 intacta (SHA-256)',crypto.createHash('sha256').update(fs.readFileSync(path.join(ROOT,'base_canonica','AC-ICEN_MVP_2_7_0_20261013_CANONICA.html'))).digest('hex')===fs.readFileSync(path.join(ROOT,'base_sha256.txt'),'utf8').trim());
 // 2) lector + M7 con el PDF del caso maestro
 await p.evaluate(()=>go('real-contraparte'));
 await p.setInputFiles('#mvFile',CASO);await p.waitForSelector('#m7Out .card',{timeout:60000});
 const m=await p.evaluate(()=>({cl:M7S.res.coverage.candidateClauseCount,al:M7S.alerts.length,ob:M7S.obs.length,txt:document.getElementById('m7Out').innerText,doc:MV.docs[0],hdr:M7S.res.documents[0].clauses.filter(c=>/DOCUMENTO SIMULADO|Caso ICEN 2027/.test(c.evidence)).length,pags:Math.max(...M7S.res.documents[0].clauses.map(c=>c.page))}));
 t('PDF maestro: se leen 18 páginas',m.doc.pages.length===18,String(m.doc.pages.length));t('PDF maestro: >25 cláusulas candidatas en M7',m.cl>25,String(m.cl));
 t('M7 recibe páginas reales (hasta la 18)',m.pags>=17,String(m.pags));t('encabezados repetidos filtrados genéricamente',m.hdr===0,String(m.hdr));
 t('hallazgos muestran documento, página y sección',/página \d+/.test(m.txt)&&/ANEXO|CLAUSULA|ARTICULO/.test(m.txt));t('huella SHA-256 registrada',/^[0-9a-f]{64}$/.test(m.doc.sha||''));
 t('diferencias entre cláusulas detectadas',m.al>=1,String(m.al));
 await p.click('#m7Out button:has-text("Ver en el documento original")');await p.waitForSelector('#m7Viewer mark');
 const vw=await p.evaluate(()=>({mk:document.querySelector('#m7Viewer mark').textContent.length,t:document.getElementById('m7Viewer').innerText}));t('visor resalta el fragmento original con su página',vw.mk>10&&/página \d+/.test(vw.t));
 // 3) otros formatos
 await p.evaluate(()=>mvClear());
 for(const [f,tp,pg] of [['contrato_prueba.docx','DOCX',false],['contrato_prueba.txt','TXT',false],['contrato_reportlab_4pags.pdf','PDF',true],['contrato_prueba.pdf','PDF',true]]){
  await p.evaluate(()=>mvClear());await p.setInputFiles('#mvFile',FX(f));await p.waitForFunction(()=>M7S.res||M7S.msgs.length,null,{timeout:60000});
  const r=await p.evaluate(()=>({res:!!M7S.res,tipo:MV.docs[0]&&MV.docs[0].tipo,pg:MV.docs[0]&&MV.docs[0].paginado,cl:M7S.res&&M7S.res.coverage.candidateClauseCount,txt:document.getElementById('m7Out').innerText,hay:M7S.res&&M7S.res.documents[0].clauses.some(c=>/45 d[ií]as/.test(c.evidence))}));
  t(f+': lectura y M7 ('+r.cl+' cláusulas)',r.res&&r.tipo===tp&&r.cl>=4,JSON.stringify(r).slice(0,200));
  t(f+': '+(pg?'informa página':'declara página no disponible'),pg?/página \d/.test(r.txt):/página no disponible/.test(r.txt));
  t(f+': contiene el plazo de 45 días como evidencia',!!r.hay);
 }
 const rp=await p.evaluate(()=>M7S.res.documents[0].clauses.filter(c=>/Pagina|CONTRATO DE PRUEBA XYZ/i.test(c.evidence)).length);t('PDF multipágina: encabezado repetido no entra como cláusula',rp===0);
 // 4) archivos defectuosos: mensaje claro, sin caída
 for(const [f,re] of [['pdf_sin_texto.pdf',/no contiene texto|OCR/],['corrupto.pdf',/dañado|no admitido|Invalid|inválido/i],['falso.docx',/dañado|no admitido|zip|Corrupted|end of central/i]]){
  await p.evaluate(()=>mvClear());await p.setInputFiles('#mvFile',FX(f));await p.waitForFunction(()=>M7S.msgs.length,null,{timeout:30000});
  const msg=await p.evaluate(()=>M7S.msgs.join(' | '));t(f+': error comprensible y sin cargar el documento',re.test(msg)&&(await p.evaluate(()=>MV.docs.length))===0,msg);}
 // 5) bloqueo de transferencia
 await p.evaluate(()=>mvClear());
 await p.evaluate(()=>{mvLoad('c');MV.docs.push(m7Doc('conflicto_pago.txt','Artículo 1 | Pago\n1.1 El pago se efectuará dentro de 60 días corridos desde la recepción.\nArtículo 2 | Excepciones\n2.1 Salvo acuerdo escrito, el pago de la Orden urgente será a 45 días.'));mvRun()});
 await p.waitForSelector('#m7Out .card');
 const g=await p.evaluate(()=>({al:M7S.alerts.map(a=>a.topic),bl:m7Blocked()}));t('conflicto de plazos genera alerta y retiene el plazo de pago',g.al.includes('pago')&&g.bl.includes('c_pay'),JSON.stringify(g));
 await p.evaluate(()=>{go('real-calculadora');document.getElementById('c_pay').value=99;go('real-contraparte');document.getElementById('mvConfirm').checked=true;mvSend()});
 const s1=await p.evaluate(()=>({pay:document.getElementById('c_pay').value,src:document.getElementById('c_src').innerText}));
 t('sin revisión humana el plazo NO pasa a la calculadora (queda 99)',s1.pay==='99'&&/ninguna conclusión jurídica/.test(s1.src)&&/retenidos/.test(s1.src),JSON.stringify(s1));
 await p.evaluate(()=>{go('real-contraparte');M7S.alerts.forEach(a=>m7Rev(a.id,'revisada'));M7S.obs.forEach((o,i)=>m7Rev('OBS'+i,'revisada'));document.getElementById('mvConfirm').checked=true;mvSend()});
 const s2=await p.evaluate(()=>({pay:document.getElementById('c_pay').value,sale:document.getElementById('c_sale').value}));
 t('tras revisión humana el valor numérico sí se transfiere (60)',s2.pay==='60',JSON.stringify(s2));
 t('M7 nunca habilita exportación financiera automática',await p.evaluate(()=>M7S.res.safety.financialExportAllowed===false&&M7S.res.issues.every(i=>i.legalConclusion===null)));
 // 6) funciones previas
 const k=await p.evaluate(()=>{go('real-calculadora');calc();return document.getElementById('c_out').innerText.length});t('calculadora previa sigue calculando',k>200);
 await p.evaluate(()=>{go('real-contraparte');mvClear();mvLoad('p');mvLoad('f')});const f=await p.evaluate(()=>document.getElementById('mvOut').innerText);t('análisis previo de pagos y ratios sigue funcionando',/Pago observado|Ratios financieros/.test(f));
 t('sin errores de consola durante toda la sesión',errs.length===0,errs.join(' | '));
 await b.close();console.log(`\nRESULTADO E2E: ${ok} aprobadas, ${fail} fallidas`);process.exit(fail?1:0);
})().catch(e=>{console.log('ERROR DE PRUEBA',e);process.exit(2)});
