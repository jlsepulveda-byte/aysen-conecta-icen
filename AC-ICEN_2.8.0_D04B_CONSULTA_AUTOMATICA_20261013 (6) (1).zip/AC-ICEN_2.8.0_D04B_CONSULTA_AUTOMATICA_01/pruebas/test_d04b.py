from pathlib import Path
import ast,sqlite3,re,hashlib,sys
p=Path(__file__).resolve().parents[1]
s=(p/'AC-ICEN-MVP_2.8.0_20261013_PROPUESTA.html').read_text(encoding='utf8')
assert len(re.findall(r'<section\s+id="[^"]+"[^>]*class="[^"]*\bscreen\b',s,re.I))==55
assert 'icenAutoDesdeM7(R)' in s
assert "Promise.all(materias.map" in s
assert "if(version!==icenAutoConsultaSecuencia)return" in s
assert "Vigencia y aplicación al contrato no verificadas" in s
assert "encodeURIComponent(materia)" in s
assert "link.textContent='Abrir fuente oficial'" in s
assert "fetch('/api/juridica/consulta?materia='" in s
assert "out.replaceChildren()" in s
assert "M7S.res=ICEN.analyzeM7" in s
assert "financialExportAllowed:false" in s
assert sqlite3.connect(p/'juridica/icen_juridica.sqlite').execute('select count(*) from normas').fetchone()[0]==4
ast.parse((p/'juridica/servidor_juridico.py').read_text(encoding='utf8'))
base=p/'base_canonica/AC-ICEN_MVP_2_7_0_20261013_CANONICA.html'
assert base.exists()
print('13 comprobaciones estructurales aprobadas; 55 pantallas conservadas')
