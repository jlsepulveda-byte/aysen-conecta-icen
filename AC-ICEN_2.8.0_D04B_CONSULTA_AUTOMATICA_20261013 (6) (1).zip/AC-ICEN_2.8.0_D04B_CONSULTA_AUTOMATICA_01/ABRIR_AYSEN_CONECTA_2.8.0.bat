@echo off
start "" "%~dp0AC-ICEN-MVP_2.8.0_20261013_PROPUESTA.html"
