@echo off
cd /d "%~dp0"
py -3 juridica\servidor_juridico.py
if errorlevel 1 (echo Instale Python 3 y pruebe nuevamente. & pause)
