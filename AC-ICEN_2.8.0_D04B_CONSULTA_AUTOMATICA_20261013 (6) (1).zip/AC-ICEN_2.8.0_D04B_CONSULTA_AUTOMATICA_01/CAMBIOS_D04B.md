# D04-B — Consulta jurídica automática

Implementado sobre D04-A: al ejecutar M7 se consultan automáticamente las materias detectadas, mediante el servicio local; se muestran las fuentes y referencias en secciones desplegables, sin emitir informes por artículo.

La biblioteca mantiene **4 referencias** para PAGOS: las otras materias muestran **sin cobertura**, sin afirmar ausencia de regulación. No hay control jurídico definitivo de vigencia ni aplicación legal: se muestra expresamente como pendiente. No se transmite el documento por la API.

Pruebas realizadas: 13 comprobaciones estructurales, 55 pantallas y verificación sintáctica del JavaScript añadido. Pruebas visuales y operativas completas en Windows pendientes.

Uso: descomprimir; ejecutar `INICIAR_ICEN_D04B.bat`; abrir ICEN → Análisis de la contraparte → cargar o seleccionar contrato → Analizar → se muestran las consultas automáticas. Python 3 requerido.

La 2.7.0 de referencia sigue intacta, la calculadora continúa sin recibir conclusiones jurídicas automáticas.
